#include<iostream>
#include<string>

using namespace std;

#include "linkedlist_pranav.h"

int main()
{
	LinkedList list;

	Node* node = NULL;
	int N, c;
	int val = 1;
	string name;

	while (val == 1)
	{
		cout << "Welcome to the Shopping List Program" << endl;
		cout << "1. Add a new node at the beginning of the list" << endl;
		cout << "2. Add a new node at the end of the list" << endl;
		cout << "3. Remove the first node" << endl;
		cout << "4. Remove the last node" << endl;
		cout << "5. Remove a node from the list by entering an item number" << endl;
		cout << "6. Remove a node from the list by entering an item name" << endl;
		cout << "7. Print out the list" << endl;
		cout << "8. Exit the program" << endl;

		cout << "Please enter your choice: ";
		cin >> c;

		switch (c)
		{
		case 1: cout << "You have chosen to add a new node at the beginning of the list" << endl;
			cout << "Enter the item number: ";
			cin >> N;
			cout << "Enter the item: ";
			cin >> name; 

			node = new Node(name, N);
			list.addtoStart(node);
			list.printList();
			break;

		case 2: cout << "You have chosen to add a new node at the end of the list" << endl;
			cout << "Enter the item number: ";
			cin >> N;
			cout << "Enter the item name: ";
			cin >> name;

			node = new Node(name, N);
			list.addtoEnd(node);
			list.printList();
			break;

		case 3: cout << "You have chosen to remove the first node" << endl;
			list.removefromStart();
			list.printList();
			break;

		case 4: cout << "You have chosen to remove the last node" << endl;
			list.removefromEnd();
			list.printList();
			break;
			
		case 5: cout << "You have chosen to remove a node from the list by entering the item number" << endl;
			cout << "Enter the item number to be deleted: ";
			cin >> N;

			list.removeNodefromList(N);
			list.printList();
			break;

		case 6: cout << "You have chosen to remove a node from the list by entering the item name" << endl;
			cout << "Enter the item name to be deleted: ";
			cin >> name;

			list.removeNodefromList(name);
			list.printList();
			break;

		case 7: cout << "You have chosen to print out the list" << endl;
			list.printList();
			break;

		case 8: cout << "You have chosen to exit the program" << endl;
			exit(0);
			list.~LinkedList();
			break;

		default: cout << "Invalid choice" << endl;
			val = 0;
			break;
		}
	}

	return 0;
}

