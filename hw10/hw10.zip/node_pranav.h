#ifndef node_h
#define node_h

#include<string>

//template< class NodeType> class LinkedList;
//
//template<class NodeType>
//class Node
//{
//	friend class LinkedList<NodeType>;
//public:
//	Node(const NodeType&);
//	NodeType getData() const;
//
//private:
//	NodeType data;
//	Node<NodeType>* next;
//};

class Node
{
	friend class LinkedList;
public:
	Node();
	Node(string&, int);		//constructor

private:			//member variables to be used
	string Name;		//name of the item 
	int N;				//item number
	Node* next;		///pointer to the next item
};


#endif

