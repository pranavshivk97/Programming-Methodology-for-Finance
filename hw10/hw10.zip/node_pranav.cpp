#include<iostream>
#include<iomanip>
#include<string>

using namespace std;

#include "node_pranav.h"

Node::Node()
{

}

Node::Node(string& name, int n)
	: Name(name), N(n)
{
	this->next = NULL;
}
